package java_21_10_22_Ex02;

public class BankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
